// Mobile Menu Toggle
// This part will run on all pages
document.addEventListener('DOMContentLoaded', () => {
    // Full Schedule Popup Functionality
const viewScheduleBtn = document.getElementById('viewScheduleBtn');
const schedulePopup = document.getElementById('schedulePopup');
const popupClose = document.querySelector('.popup-close');

if (viewScheduleBtn && schedulePopup) {
    // Open popup
    viewScheduleBtn.addEventListener('click', function() {
        schedulePopup.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent background scrolling
    });

    // Close popup
    popupClose.addEventListener('click', function() {
        schedulePopup.classList.remove('active');
        document.body.style.overflow = ''; // Restore scrolling
    });

    // Close popup when clicking outside content
    schedulePopup.addEventListener('click', function(e) {
        if (e.target === schedulePopup) {
            schedulePopup.classList.remove('active');
            document.body.style.overflow = '';
        }
    });

    // Close popup with Escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && schedulePopup.classList.contains('active')) {
            schedulePopup.classList.remove('active');
            document.body.style.overflow = '';
        }
    });
}
    const mobileMenuButton = document.querySelector('.mobile-menu');
    const nav = document.querySelector('nav');
    
    if (mobileMenuButton && nav) {
        mobileMenuButton.addEventListener('click', function() {
            nav.classList.toggle('active');
        });
    }

    // Countdown Timer JavaScript
    // This part will only find elements on index.html
    const countdownTimer = document.getElementById('countdown-timer');
    if (countdownTimer) {
        function updateCountdown() {
            const matchDate = new Date('2025-11-15T15:00:00').getTime();
            const now = new Date().getTime();
            const distance = matchDate - now;
            
            if (distance < 0) {
                countdownTimer.innerHTML = "<div class='countdown-unit'><span class='countdown-value'>MATCH</span><span class='countdown-label'>IN PROGRESS</span></div>";
                clearInterval(countdownInterval); // Stop the timer
                return;
            }
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            document.getElementById('days').textContent = days.toString().padStart(2, '0');
            document.getElementById('hours').textContent = hours.toString().padStart(2, '0');
            document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
            document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
        }
        
        const countdownInterval = setInterval(updateCountdown, 1000);
        updateCountdown(); // Initial call
    }

    // Form Validation with PHP
    // This part will only find elements on contact.html
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Reset errors
            document.querySelectorAll('.form-error').forEach(error => {
                error.style.display = 'none';
            });
            
            let isValid = true;
            
            // Validate name
            const name = document.getElementById('name').value.trim();
            if (name === '') {
                document.getElementById('name-error').style.display = 'block';
                isValid = false;
            }
            
            // Validate email
            const email = document.getElementById('email').value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                document.getElementById('email-error').style.display = 'block';
                isValid = false;
            }
            
            // Validate subject
            const subject = document.getElementById('subject').value;
            if (subject === '') {
                document.getElementById('subject-error').style.display = 'block';
                isValid = false;
            }
            
            // Validate message
            const message = document.getElementById('message').value.trim();
            if (message === '') {
                document.getElementById('message-error').style.display = 'block';
                isValid = false;
            }
            
            if (isValid) {
                // Show loading state
                const submitBtn = contactForm.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                submitBtn.textContent = 'Sending...';
                submitBtn.disabled = true;
                
                // Send form data to PHP
                const formData = new FormData(contactForm);
                
                fetch('php/process-contact.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // Show success message
                        const formSuccess = document.getElementById('form-success');
                        formSuccess.textContent = data.message;
                        formSuccess.style.display = 'block';
                        contactForm.reset();
                        
                        // Scroll to success message
                        formSuccess.scrollIntoView({ behavior: 'smooth' });
                        
                        // Hide form after successful submission
                        contactForm.style.display = 'none';
                    } else {
                        // Show error message
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Sorry, there was an error sending your message. Please try again.');
                })
                .finally(() => {
                    // Reset button state
                    submitBtn.textContent = originalText;
                    submitBtn.disabled = false;
                });
            }
        });
    }
});
// Add to script.js
document.querySelectorAll('.news-card .btn').forEach(button => {
    button.addEventListener('click', function(e) {
        e.preventDefault();
        alert('Full article page would display here in a complete implementation');
    });
});